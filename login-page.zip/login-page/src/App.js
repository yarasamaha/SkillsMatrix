import login from './Components/login';
import firstLogin from './Components/firstLogin'; 
import {Switch, Route,BrowserRouter} from 'react-router-dom'
import {Container} from '@material-ui/core'

function App() {
  return (
    <>
    <Container maxWidth="md"> 
    <BrowserRouter>
    <div className="app">
      <Switch>
        <Route path="/login" component={login}/>
        <Route path="/setUserPassword" component={firstLogin}/> 
      </Switch>
      </div>
    </BrowserRouter>
    </Container>
   
    </>
  );
}

export default App;
