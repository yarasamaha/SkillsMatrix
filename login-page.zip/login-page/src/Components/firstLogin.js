import { Button, TextField, FormControlLabel } from '@material-ui/core';
import React from 'react';
import PersonIcon from '@material-ui/icons/Person';
import CheckBox from '@material-ui/core/CheckBox';
import CheckBoxIconBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import { useState } from 'react';
import { getCookie, setCookie } from "./Helper";
import { Link } from 'react-router-dom';

const FirstLogin = () => {

    const [mail, setMail] = useState('');
    const [password1, setPassword1] = useState('');
    const [password2, setPassword2] = useState('');
    const [isWrong, setIsWrong] = useState(false);
    const [notSame, setNotSame] = useState(false);

    const onButtonClick = (e) => {
        console.log(mail);
        console.log(password1);
        console.log(password2);

        if(password2 !== password1){
            setNotSame(true);
            console.log("hereeeeeee");
            return ;
        }

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        var raw = JSON.stringify({
            "mail": mail,
            "password": password1
        });

        var requestOptions = {
            method: 'PUT',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };

        fetch("http://localhost:8080/api/userLogin/setPassword", requestOptions)
            .then(response => response.json())
            .then(result => {

                console.log(result.id)

                if(result.id === 0 ){
                    // <h1>wrong</h1>
                    setIsWrong(true);
                }

                if(result.id ){
                    console.log("entered");
                    //redirect to profile
                    window.location.href = "/login";
                }

            })
    }

    return (
        <div>
            {isWrong && <h4>weak password</h4>}
            {notSame && <h4>please enter the same password</h4>}
            <div className="icon">
                <div className="icon_class">
                    <PersonIcon fontsSize="large" />
                </div>
                <div className="text">Log in</div>
            </div>

            <div className="row m-2">
                <TextField id="Username" className="p-2" type="text" variant="outlined"
                    onChange={(event) => {
                        setMail(event.target.value)
                    }}
                    label="Enter username" fullWidth />
                <TextField id="Password" className="p-2" type="password" variant="outlined"
                    onChange={(event) => {
                        setPassword1(event.target.value)
                    }}
                    label="Enter password" fullWidth />
                <TextField id="Password" className="p-2" type="password" variant="outlined"
                    onChange={(event) => {
                        setPassword2(event.target.value)
                    }}
                    label="Re-enter password" fullWidth />

                <FormControlLabel
                    control={
                        <CheckBox
                            icon={<CheckBoxIconBlankIcon fontSize="small" />}
                            name="checkedI"
                        />
                    }
                />
                <Button variant="contained" color="primary" onClick={onButtonClick}
                    fullWidth>Log in</Button>
            </div>
        </div>
    )
}


export default FirstLogin;
