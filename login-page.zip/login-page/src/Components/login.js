import { Button, TextField, FormControlLabel } from '@material-ui/core';
import React from 'react';
import PersonIcon from '@material-ui/icons/Person';
import CheckBox from '@material-ui/core/CheckBox';
import CheckBoxIconBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import { useState } from 'react';
import { getCookie,setCookie } from "./Helper";
import { Link } from 'react-router-dom';

const Login = () => {
    const [userName, setUserName] = useState('');
    const [password, setPassword] = useState('');
    const [isWrong, setIsWrong] = useState(false);

    const onButtonClick = (e) => {
        console.log(userName);
        console.log(password);

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        var raw = JSON.stringify({
            "mail": userName,
            "password": password
        });

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };

        fetch("http://localhost:8080/api/userLogin/checkEmail", requestOptions)
            .then(response => response.json())
            .then(result => {

                if(result.firstTimeFlag){
                    console.log("entered one");
                    window.location.href = "/setUserPassword"
                    return ;
                }

                if(result.id && !result.isFirstTime){
                    console.log("entered two");
                    //redirect to profile
                    window.location.href = "/";
                    return ;
                }

                if(result.id === 0){
                    // <h1>wrong</h1>
                    setIsWrong(true);
                    
                }
            })
    }
    return (
        <div>
            {isWrong && <h4>wrong username or password</h4>}
            <div className="icon">
                <div className="icon_class">
                    <PersonIcon fontsSize="large" />
                </div>
                <div className="text">Log in</div>
            </div>
            <div className="row m-2">
                <TextField id="Username" className="p-2" type="text" variant="outlined"
                    onChange={(event) => {
                        setUserName(event.target.value)
                    }}
                    label="Enter username" fullWidth />
                <TextField id="Password" className="p-2" type="password" variant="outlined"
                    onChange={(event) => {
                        setPassword(event.target.value)
                    }}
                    label="Enter password" fullWidth />
                <FormControlLabel
                    control={
                        <CheckBox
                            icon={<CheckBoxIconBlankIcon fontSize="small" />}
                            name="checkedI"
                        />
                    }
                />
                <Button variant="contained" color="primary" onClick={onButtonClick}
                    fullWidth>Log in</Button>
            </div>
        </div>
    )
}

export default Login;
