package com.cegedim.skillsmatrix.models;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.Data;

@Data
@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long id;
	private String name;
	private Integer grossSalary;
	private Integer netSalary;
	private String mail;
	private String password;
	private String mobile;
	private Boolean isAdmin;
	private Boolean isApproved;
	private Boolean isFirstTime;
	
	@OneToMany(mappedBy= "employee")
    Set<EmployeeSkill> employeesSkills;
	
	@ManyToOne
	@JoinColumn(name="manager_id")
	Employee managerId;
	
	@ManyToOne
	@JoinColumn(name="team_id")
    Team teamId;
	
	@ManyToOne
	@JoinColumn(name="job_role_id")
	JobRoles jobRoleId;
	
	
	
	public Integer getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(Integer netSalary) {
		this.netSalary = netSalary;
	}

	public Set<EmployeeSkill> getEmployeesSkills() {
		return employeesSkills;
	}

	public void setEmployeesSkills(Set<EmployeeSkill> employeesSkills) {
		this.employeesSkills = employeesSkills;
	}

	public Employee getManagerId() {
		return managerId;
	}

	public void setManagerId(Employee managerId) {
		this.managerId = managerId;
	}

	public Team getTeamId() {
		return teamId;
	}

	public void setTeamId(Team teamId) {
		this.teamId = teamId;
	}

	public JobRoles getJobRoleId() {
		return jobRoleId;
	}

	public void setJobRoleId(JobRoles jobRoleId) {
		this.jobRoleId = jobRoleId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getGrossSalary() {
		return grossSalary;
	}

	public void setGrossSalary(Integer grossSalary) {
		this.grossSalary = grossSalary;
	}

	public Integer getNetSallary() {
		return netSalary;
	}

	public void setNetSallary(Integer netSalary) {
		this.netSalary = netSalary;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Boolean getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = false;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = true;
	}

	public Boolean getIsFirstTime() {
		return isFirstTime;
	}

	public void setIsFirstTime(Boolean isFirstTime) {
		this.isFirstTime = true;
	}
	
	public void firstTimeSetter(Boolean isFirstTime) {
		this.isFirstTime = isFirstTime;
	}
	
	


}
