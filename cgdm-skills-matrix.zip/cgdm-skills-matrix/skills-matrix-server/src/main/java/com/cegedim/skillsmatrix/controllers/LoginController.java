package com.cegedim.skillsmatrix.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cegedim.skillsmatrix.dtos.EmployeeLoginDTO;
import com.cegedim.skillsmatrix.services.LoginService;

@SpringBootApplication
@RequestMapping("/api/userLogin")
@RestController
@CrossOrigin
public class LoginController {
	
	@Autowired
	LoginService my_login_service;
	
	//@CrossOrigin
	@PostMapping("/checkEmail")
	public EmployeeLoginDTO check_email(@RequestBody EmployeeLoginDTO my_employee_dto) {
		return my_login_service.check_email(my_employee_dto.getMail(),my_employee_dto.getPassword(),my_employee_dto.getIsFirstTime());
	}
	
	//@CrossOrigin(origins = "http://127.0.0.1:3000")
	@PostMapping("/checkEmail&Password")
	public EmployeeLoginDTO check_email_and_password(@RequestBody EmployeeLoginDTO my_employee_dto) {
		return my_login_service.check_email_and_password(my_employee_dto.getMail(),my_employee_dto.getPassword());
	}
	
	//@CrossOrigin(origins = "http://127.0.0.1:3000")
	@PutMapping("/setPassword")
	public EmployeeLoginDTO set_password(@RequestBody EmployeeLoginDTO my_employee_dto) {
		return my_login_service.set_password(my_employee_dto.getMail(), my_employee_dto.getPassword());
	}
}
