package com.cegedim.skillsmatrix.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cegedim.skillsmatrix.models.Employee;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Long> {

	@Query(value = "SELECT ID,GROSS_SALARY,IS_ADMIN,IS_APPROVED,MAIL,MOBILE,NAME,NET_SALARY,PASSWORD,JOB_ROLE_ID,MANAGER_ID,TEAM_ID,IS_FIRST_TIME FROM EMPLOYEE WHERE " +
		       "MAIL " + 
			   " = :mail",
		       nativeQuery = true
				)
	Employee get_employee_by_mail(@Param("mail") String mail);
	
	@Query(value = "SELECT ID,GROSS_SALARY,IS_ADMIN,IS_APPROVED,MAIL,MOBILE,NAME,NET_SALARY,PASSWORD,JOB_ROLE_ID,MANAGER_ID,TEAM_ID FROM EMPLOYEE WHERE " +
		       "MAIL " + 
			   " = :mail and PASSWORD = :password" ,
		       nativeQuery = true
				)
	Employee get_employee_by_mail_and_password(@Param("mail") String mail,@Param("password") String password);
	
}

