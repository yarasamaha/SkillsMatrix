package com.cegedim.skillsmatrix.models;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

import lombok.Data;


@Data
@Entity
public class EmployeeSkill {
	@EmbeddedId
	EmployeeSkillKey id;
	
	@ManyToOne
	@MapsId("employeeId")
    @JoinColumn(name = "employee_id")
	Employee employee;
	
	@ManyToOne
	@MapsId("skillId")
    @JoinColumn(name = "skill_id")
	Skill skill;
	
	private Integer level;
	private String attachmentPath;
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public String getAttachmentPath() {
		return attachmentPath;
	}
	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}
	
	
}
