package com.cegedim.skillsmatrix.mappers;

import org.springframework.stereotype.Component;

import com.cegedim.skillsmatrix.dtos.EmployeeLoginDTO;
import com.cegedim.skillsmatrix.models.Employee;

@Component
public class EmployeeMapper {
	
	public EmployeeLoginDTO toDTO(Employee my_employee) {
		EmployeeLoginDTO my_employee_dto = new EmployeeLoginDTO();
		my_employee_dto.setId(my_employee.getId());
		my_employee_dto.setName(my_employee.getName());
		my_employee_dto.setGrossSalary(my_employee.getGrossSalary());
		my_employee_dto.setIsAdmin(my_employee.getIsAdmin());
		my_employee_dto.setIsApproved(my_employee.getIsApproved());
		my_employee_dto.setMail(my_employee.getMail());
		my_employee_dto.setMobile(my_employee.getMobile());
		my_employee_dto.setNetSalary(my_employee_dto.getNetSalary());
		my_employee_dto.setPassword(my_employee.getPassword());
		my_employee_dto.setNetSalary(my_employee.getNetSalary());
		my_employee_dto.setIsFirstTime(my_employee.getIsFirstTime());
		return my_employee_dto;
	}
	
	public Employee toEmployee(EmployeeLoginDTO my_employee_dto) {
		Employee my_employee = new Employee();
		my_employee.setId(my_employee_dto.getId());
		my_employee.setName(my_employee_dto.getName());
		my_employee.setGrossSalary(my_employee_dto.getGrossSalary());
		my_employee.setIsAdmin(my_employee_dto.getIsAdmin());
		my_employee.setIsApproved(my_employee_dto.getIsApproved());
		my_employee.setMail(my_employee_dto.getMail());
		my_employee.setMobile(my_employee_dto.getMobile());
		my_employee.setNetSalary(my_employee_dto.getNetSalary());
		my_employee.setPassword(my_employee_dto.getPassword());
		my_employee.setNetSalary(my_employee_dto.getNetSalary());
		my_employee.setIsFirstTime(my_employee_dto.getIsFirstTime());
		return my_employee;
	}
}
