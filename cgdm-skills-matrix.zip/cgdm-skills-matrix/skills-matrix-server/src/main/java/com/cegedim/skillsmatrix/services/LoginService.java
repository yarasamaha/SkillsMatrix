package com.cegedim.skillsmatrix.services;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cegedim.skillsmatrix.dtos.EmployeeLoginDTO;
import com.cegedim.skillsmatrix.mappers.EmployeeMapper;
import com.cegedim.skillsmatrix.models.Employee;
import com.cegedim.skillsmatrix.repositories.EmployeeRepo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Transactional
public class LoginService {
	
	@Autowired
	EmployeeRepo my_employee_repo;
	
	@Autowired 
	EmployeeMapper my_employee_mapper;
	
	@Autowired
	EntityManager my_entity_manager;
	
	public EmployeeLoginDTO check_email(String mail,String password,Boolean isFirstTime) {
		Employee my_employee = my_employee_repo.get_employee_by_mail(mail);
		EmployeeLoginDTO null_employee_dto = new EmployeeLoginDTO();
		null_employee_dto.setMail("lol");
		null_employee_dto.setId((long)0);
		if(my_employee == null) return null_employee_dto;
		if(my_employee.getIsFirstTime().equals(true) && password.equals("cegedim") == true ) {
			if(my_employee.getPassword().equals("cegedim")) {
				my_employee.firstTimeSetter(false);
				my_entity_manager.merge(my_employee);
				EmployeeLoginDTO my_employee_dto = my_employee_mapper.toDTO(my_employee);
				my_employee_dto.setFirstTimeSetter(true);
				return my_employee_dto ;
			}
		}
		if(my_employee.getIsFirstTime().equals(false) && password.equals("cegedim") == false  ) {
			Employee check_acountEmployee = my_employee_repo.get_employee_by_mail_and_password(mail,password);
			if(check_acountEmployee == null) return null_employee_dto;
			return my_employee_mapper.toDTO(check_acountEmployee);
		}
		return null_employee_dto;
	}
	
	public EmployeeLoginDTO check_email_and_password(String mail,String password) {
		Employee my_employee = my_employee_repo.get_employee_by_mail_and_password(mail,password);
		if(my_employee == null) return null;
		EmployeeLoginDTO my_employee_dto = my_employee_mapper.toDTO(my_employee);
		return my_employee_dto;
	}
	
	public EmployeeLoginDTO set_password(String mail,String password) {
		Employee my_employee = my_employee_repo.get_employee_by_mail(mail);
		Pattern special_character_pattern = Pattern.compile("[^a-z0-9 ]",Pattern.CASE_INSENSITIVE);
		Matcher special_matcher = special_character_pattern.matcher(password);
		boolean special = special_matcher.find();
		EmployeeLoginDTO null_employee_dto = new EmployeeLoginDTO();
		null_employee_dto.setId((long)0);
		null_employee_dto.setMail("lol");
		System.out.println(special);
		if(special == false) {
			return null_employee_dto;
		}
		Pattern uppercase_character_pattern = Pattern.compile("[A-Z ]");
		Matcher upper_matcher = uppercase_character_pattern.matcher(password);
		boolean upper = upper_matcher.find();
		if(upper == false) {
			return null_employee_dto;
		}
		if(my_employee.getIsFirstTime().equals("true")) {
			return null_employee_dto;
		}
		my_employee.setPassword(password);
		my_entity_manager.merge(my_employee);
		return my_employee_mapper.toDTO(my_employee);
	}

}
