package com.cegedim.skillsmatrix.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Embeddable
@Data
public class EmployeeSkillKey implements Serializable{
	@Column(name = "employee_id")
	private Long employeeId;
	
	@Column(name = "skill_id")
	private Long skillId;
	
}
