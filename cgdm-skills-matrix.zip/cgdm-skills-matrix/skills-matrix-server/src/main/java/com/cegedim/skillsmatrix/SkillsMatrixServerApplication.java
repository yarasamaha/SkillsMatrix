package com.cegedim.skillsmatrix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillsMatrixServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillsMatrixServerApplication.class, args);
	}

}
