package com.cegedim.skillsmatrix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillsMatrixServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
